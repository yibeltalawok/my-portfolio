<<<<<<< HEAD
import './App.css';
import MenuBar from './components/MenuBar' 
function App () {
  return (
      <>
      <MenuBar />
      </>
    )}
=======
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

>>>>>>> bb00f6e180b41e3a77a790c9dc6bd9fe8cfb5d53
export default App;
