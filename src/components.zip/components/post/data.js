import { Phone } from "@mui/icons-material";
export const data = [
      {name: 'Name',value: 'Yibeltal Awoke'},
      {name:"Phone",value:"0964727916"},
      {name:"E-mail",value:"yibeltalawoke058@gmail.com"},
      {name:"Birth Date",value:"Feubrary 19/1994"},
      {name:"Birth Of Place",value:"Durbete"},
      {name:"Region",value:"Amhara(3)"},
      {name:"Nationality",value:"Ethiopian"},
      {name:"Secondary school",value:"Durbete Secondary"},
      {name:"preparatory school",value:"Durbete preparatory"},
      {name:"Year of grade(9-12)",value:"2003-2006 E.C"},
      {name:"University Education",value:"2007-2011 E.C"},
    //   {name:"Year of grade(9-12)",value:"2003-2006 E.C"},
     ];