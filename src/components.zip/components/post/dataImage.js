export const dataAllow = [
    {
      HOA:2000,
      HEA: 400,
      TRA:200,
      POA:2000,
      PF:3000,
      PRAR:3000,
      ERTR:200,
      id:4,
      Year:20223
    },
    {
        HOA:2000,
        HEA: 400,
        TRA:200,
        POA:2000,
        PF:3000,
        PRAR:3000,
        ERTR:200,
        id:3,
        Year:20223
      },
      {
        HOA:2000,
        HEA: 400,
        TRA:200,
        POA:2000,
        PF:3000,
        PRAR:3000,
        ERTR:200,
        id:2,
        Year:20223
      }
  ];